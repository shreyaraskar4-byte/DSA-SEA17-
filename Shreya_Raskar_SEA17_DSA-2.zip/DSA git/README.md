# DSA Lab – Shreya Raskar

**Name:** Shreya Raskar  
**Roll No.:** SEA17

This repository contains Data Structures and Algorithms lab practicals.
